﻿using BlazorApp.Models;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BlazorApp.Services
{
    public class CustomerService
    {
        MainDbContext _dbContext = new MainDbContext();
        public async Task<List<Customer>> GetCustomersAsync()
        {
            try
            {
                return await _dbContext.CustomerRecord.Find(_ => true).ToListAsync().ConfigureAwait(false);
            }
            catch
            {
                throw;
            }
        }
        public async Task CreateCustomerAsync(Customer customer)
        {
            try
            {
                await _dbContext.CustomerRecord.InsertOneAsync(customer);
            }
            catch
            {
                throw;
            }
        }
        public async Task<Customer> GetCustomerByIdAsync(string id)
        {
            try
            {
                FilterDefinition<Customer> customerFilter = Builders<Customer>.Filter.Eq("Id", id);
                return await _dbContext.CustomerRecord.FindSync(customerFilter).FirstOrDefaultAsync();
            }
            catch
            {
                throw;
            }
        }
        public async Task UpdateCustomerAsync(Customer customer)
        {
            try
            {
                await _dbContext.CustomerRecord.ReplaceOneAsync(filter: g => g.Id == customer.Id, replacement: customer);
            }
            catch
            {
                throw;
            }
        }
        public async Task DeleteCustomerAsync(string id)
        {
            try
            {
                FilterDefinition<Customer> customerData = Builders<Customer>.Filter.Eq("Id", id);
                await _dbContext.CustomerRecord.DeleteOneAsync(customerData);
            }
            catch
            {
                throw;
            }
        }
    }
}
