﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApp.Models
{
    public class MainDbContext
    {
        private readonly IMongoDatabase _mongoDatabase;

        public MainDbContext()
        {
            var customer = new MongoClient("mongodb://localhost:27017");
            _mongoDatabase = customer.GetDatabase("CustomersDB");
        }
            public IMongoCollection<Customer> CustomerRecord
        {
            get
            {
                return _mongoDatabase.GetCollection<Customer>("CustomerRecord");
            }
        }
    }
 }

