﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using BlazorApp.Models;
using BlazorApp.Services;

public class CustomerController : Controller
{
    CustomerService service = new CustomerService();
    
    [HttpGet]
    [Route("api/customer/index")]
    public async Task<IEnumerable<Customer>> Index()
    {
        return await service.GetCustomersAsync();
    }

    [HttpPost]
    [Route("api/customer/create")]
    public async Task Create([FromBody] Customer customer)
    {
        await service.CreateCustomerAsync(customer);
    }

    [HttpGet]
    [Route("api/customer/details/{id}")]
    public async Task<Customer> Details(string id)
    {
        return await service.GetCustomerByIdAsync(id);
    }

    [HttpPut]
    [Route("api/customer/edit")]
    public async Task Edit([FromBody] Customer customer)
    {
        await service.UpdateCustomerAsync(customer);
    }

    [HttpDelete]
    [Route("api/customer/delete/{id}")]
    public async Task Delete(string id)
    {
        await service.DeleteCustomerAsync(id);
    }
    
}

